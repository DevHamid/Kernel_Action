### AnyKernel3 Ramdisk Mod Script
## osm0sis @ xda-developers
## wayne / sdm660 / Xiaomi Mi 8 Lite - kernel-only, keeps the device's own ramdisk

### AnyKernel setup
# global properties
properties() { '
kernel.string=LKGeek-perf-devhamid 4.19.325-cip136-st20
do.devicecheck=1
do.modules=0
do.systemless=0
do.cleanup=1
do.cleanuponabort=0
device.name1=wayne
supported.versions=
supported.patchlevels=
supported.vendorpatchlevels=
'; } # end properties


### AnyKernel install
## boot files attributes
boot_attributes() {
set_perm_recursive 0 0 755 644 $RAMDISK/*;
set_perm_recursive 0 0 750 750 $RAMDISK/init* $RAMDISK/sbin;
} # end attributes

# boot shell variables
BLOCK=/dev/block/bootdevice/by-name/boot;
IS_SLOT_DEVICE=0;
RAMDISK_COMPRESSION=auto;
PATCH_VBMETA_FLAG=auto;

# import functions/variables and setup patching - see for reference (DO NOT REMOVE)
. tools/ak3-core.sh;

# boot install
# split_boot, not dump_boot: replace kernel + appended DTB only, leave the
# device's own ramdisk untouched so FBE/decryption keeps working.
split_boot;

flash_boot;
## end boot install
